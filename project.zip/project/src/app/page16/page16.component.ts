import { Component } from '@angular/core';

@Component({
  selector: 'app-page16',
  imports: [],
  templateUrl: './page16.component.html',
  styleUrl: './page16.component.css'
})
export class Page16Component {

}
