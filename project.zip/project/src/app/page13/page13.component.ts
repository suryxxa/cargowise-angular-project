import { Component } from '@angular/core';

@Component({
  selector: 'app-page13',
  imports: [],
  templateUrl: './page13.component.html',
  styleUrl: './page13.component.css'
})
export class Page13Component {

}
