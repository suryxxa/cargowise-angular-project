import { CommonModule } from '@angular/common';
import { Component, input, output } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-left-sidebar',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './left-sidebar.component.html',
  styleUrl: './left-sidebar.component.css',
})
export class LeftSidebarComponent {
  isLeftSidebarCollapsed = input.required<boolean>();
  changeIsLeftSidebarCollapsed = output<boolean>();
  items = [
    {
      routeLink: 'page1',
      icon: 'fal fa-file',
      label: 'page1',
    },
    {
      routeLink: 'page2',
      icon: 'fal fa-file',
      label: 'page2',
    },
    {
      routeLink: 'page3',
      icon: 'fal fa-file',
      label: 'page3',
    },
    {
      routeLink: 'page4',
      icon: 'fal fa-file',
      label: 'page4',
    },
    {
      routeLink: 'page5',
      icon: 'fal fa-file',
      label: 'page5',
    },
    {
      routeLink: 'page6',
      icon: 'fal fa-file',
      label: 'page6',
    },
    {
      routeLink: 'page7',
      icon: 'fal fa-file',
      label: 'page7',
    },
    {
      routeLink: 'page8',
      icon: 'fal fa-file',
      label: 'page8',
    },
    {
      routeLink: 'page9',
      icon: 'fal fa-file',
      label: 'page9',
    },
    {
      routeLink: 'page10',
      icon: 'fal fa-file',
      label: 'page10',
    },
    {
      routeLink: 'page11',
      icon: 'fal fa-file',
      label: 'page11',
    },
    {
      routeLink: 'page12',
      icon: 'fal fa-file',
      label: 'page12',
    },
    {
      routeLink: 'page13',
      icon: 'fal fa-file',
      label: 'page13',
    },
    {
      routeLink: 'page14',
      icon: 'fal fa-file',
      label: 'page14',
    },
    {
      routeLink: 'page15',
      icon: 'fal fa-file',
      label: 'page15',
    },
    {
      routeLink: 'page16',
      icon: 'fal fa-file',
      label: 'page16',
    },
    {
      routeLink: 'page17',
      icon: 'fal fa-file',
      label: 'page17',
    },
    {
      routeLink: 'page18',
      icon: 'fal fa-file',
      label: 'page18',
    },
  ];

  toggleCollapse(): void {
    this.changeIsLeftSidebarCollapsed.emit(!this.isLeftSidebarCollapsed());
  }

  closeSidenav(): void {
    this.changeIsLeftSidebarCollapsed.emit(true);
  }
}
