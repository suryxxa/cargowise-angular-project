import { Component } from '@angular/core';

@Component({
  selector: 'app-page6',
  imports: [],
  templateUrl: './page6.component.html',
  styleUrl: './page6.component.css'
})
export class Page6Component {

}
