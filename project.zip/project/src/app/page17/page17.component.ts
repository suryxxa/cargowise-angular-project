import { Component } from '@angular/core';

@Component({
  selector: 'app-page17',
  imports: [],
  templateUrl: './page17.component.html',
  styleUrl: './page17.component.css'
})
export class Page17Component {

}
