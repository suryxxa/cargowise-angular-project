


import { Component } from '@angular/core';

@Component({
  selector: 'app-page10',
  templateUrl: './page10.component.html',
  styleUrls: ['./page10.component.css']
})
export class Page10Component {
  selectedType: string = '';
  selectedContainerType: string = '';

  // Method to set the selected container type
  selectContainerType(type: string) {
    this.selectedContainerType = type;
  }

  // Correctly defining the onTypeChange method
  onTypeChange(event: Event): void {
    const target = event.target as HTMLSelectElement;  // Type casting to HTMLSelectElement
    if (target) {
      this.selectedType = target.selectedOptions[0]?.text || ''; // Handling null or undefined values
    }
  }
}
