import { Component } from '@angular/core';

@Component({
  selector: 'app-page14',
  imports: [],
  templateUrl: './page14.component.html',
  styleUrl: './page14.component.css'
})
export class Page14Component {

}
