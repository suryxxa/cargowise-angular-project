import { Component } from '@angular/core';

@Component({
  selector: 'app-page7',
  imports: [],
  templateUrl: './page7.component.html',
  styleUrl: './page7.component.css'
})
export class Page7Component {

}
