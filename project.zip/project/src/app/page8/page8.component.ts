import { Component } from '@angular/core';

@Component({
  selector: 'app-page8',
  imports: [],
  templateUrl: './page8.component.html',
  styleUrl: './page8.component.css'
})
export class Page8Component {

}
