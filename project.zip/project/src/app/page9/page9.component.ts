


import { Component } from '@angular/core';

@Component({
  selector: 'app-page9',
  imports: [],
  templateUrl: './page9.component.html',
  styleUrl: './page9.component.css'
})
export class Page9Component {
  selectedType: string ='';
  onTypeChange(event: any){
    this.selectedType = event.target.selectedOptions[0].text;
  }
  addRow() {
    let tableBody = document.getElementById("tableBody");
    if(tableBody) {
      let newRow = tableBody.children[0]?.cloneNode(true);
      tableBody.appendChild(newRow);
    }
  }

}
