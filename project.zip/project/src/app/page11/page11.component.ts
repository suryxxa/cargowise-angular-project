import { Component } from '@angular/core';

@Component({
  selector: 'app-page11',
  imports: [],
  templateUrl: './page11.component.html',
  styleUrl: './page11.component.css'
})
export class Page11Component {

}
