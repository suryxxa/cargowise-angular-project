import { Component } from '@angular/core';

@Component({
  selector: 'app-page12',
  imports: [],
  templateUrl: './page12.component.html',
  styleUrl: './page12.component.css'
})
export class Page12Component {

}
