import { Component } from '@angular/core';

@Component({
  selector: 'app-page5',
  imports: [],
  templateUrl: './page5.component.html',
  styleUrl: './page5.component.css'
})
export class Page5Component {

}
