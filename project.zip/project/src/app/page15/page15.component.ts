import { Component } from '@angular/core';

@Component({
  selector: 'app-page15',
  imports: [],
  templateUrl: './page15.component.html',
  styleUrl: './page15.component.css'
})
export class Page15Component {

}
