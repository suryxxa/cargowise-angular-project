import { Component } from '@angular/core';

@Component({
  selector: 'app-page18',
  imports: [],
  templateUrl: './page18.component.html',
  styleUrl: './page18.component.css'
})
export class Page18Component {

}
